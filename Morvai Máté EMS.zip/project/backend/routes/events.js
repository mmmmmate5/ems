import express from 'express';
import pool from '../config/database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get all events for the authenticated user
router.get('/', async (req, res) => {
  try {
    const [events] = await pool.execute(
      'SELECT * FROM events WHERE user_id = ? ORDER BY occurrence ASC',
      [req.user.id]
    );

    res.json(events);
  } catch (error) {
    console.error('Get events error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create a new event
router.post('/', async (req, res) => {
  try {
    const { title, occurrence, description } = req.body;

    if (!title || !occurrence) {
      return res.status(400).json({ error: 'Title and occurrence are required' });
    }

    const [result] = await pool.execute(
      'INSERT INTO events (user_id, title, occurrence, description) VALUES (?, ?, ?, ?)',
      [req.user.id, title, occurrence, description || null]
    );

    const [newEvent] = await pool.execute(
      'SELECT * FROM events WHERE id = ?',
      [result.insertId]
    );

    res.status(201).json(newEvent[0]);
  } catch (error) {
    console.error('Create event error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update an event
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, occurrence, description } = req.body;

    if (!title || !occurrence) {
      return res.status(400).json({ error: 'Title and occurrence are required' });
    }

    // Check if event belongs to user
    const [events] = await pool.execute(
      'SELECT * FROM events WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (events.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    await pool.execute(
      'UPDATE events SET title = ?, occurrence = ?, description = ? WHERE id = ? AND user_id = ?',
      [title, occurrence, description || null, id, req.user.id]
    );

    const [updatedEvent] = await pool.execute(
      'SELECT * FROM events WHERE id = ?',
      [id]
    );

    res.json(updatedEvent[0]);
  } catch (error) {
    console.error('Update event error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete an event
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Check if event belongs to user
    const [events] = await pool.execute(
      'SELECT * FROM events WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (events.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    await pool.execute(
      'DELETE FROM events WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    res.json({ message: 'Event deleted successfully' });
  } catch (error) {
    console.error('Delete event error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;