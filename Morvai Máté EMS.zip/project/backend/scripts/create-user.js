import bcrypt from 'bcryptjs';
import pool from '../config/database.js';

const createUser = async () => {
  const email = process.argv[2];
  const password = process.argv[3];

  if (!email || !password) {
    console.log('Usage: node scripts/create-user.js <email> <password>');
    process.exit(1);
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 12);
    
    await pool.execute(
      'INSERT INTO users (email, password) VALUES (?, ?)',
      [email, hashedPassword]
    );

    console.log(`User created successfully: ${email}`);
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      console.log('User already exists with this email');
    } else {
      console.error('Error creating user:', error);
    }
  } finally {
    process.exit(0);
  }
};

createUser();