import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, HelpCircle } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatbotProps {
  user?: { email: string } | null;
}

const Chatbot: React.FC<ChatbotProps> = ({ user }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        text: `Hello${user ? ` ${user.email}` : ''}! 👋 I'm your Event Management assistant. I can help you with:\n\n• Creating and managing events\n• Account and login issues\n• Password reset help\n• General navigation\n• Feature explanations\n\nWhat would you like to know?`,
        isBot: true,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, user]);

  const getResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();

    if (message.includes('create') && message.includes('event')) {
      return "To create a new event:\n\n1. Click the '+ Add Event' button on your dashboard\n2. Fill in the event title (required)\n3. Select date and time\n4. Add an optional description\n5. Click 'Create' to save\n\nYour event will appear on your dashboard immediately!";
    }

    if (message.includes('edit') || message.includes('update')) {
      return "To edit an event:\n\n1. Find your event on the dashboard\n2. Click the edit icon (pencil) on the event card\n3. Modify the details in the popup form\n4. Click 'Update' to save changes\n\nYou can edit the title, date/time, and description anytime.";
    }

    if (message.includes('delete') || message.includes('remove')) {
      return "To delete an event:\n\n1. Locate the event on your dashboard\n2. Click the trash icon on the event card\n3. Confirm deletion in the popup\n\n⚠️ Warning: Deleted events cannot be recovered!";
    }

    if (message.includes('password') && (message.includes('forgot') || message.includes('reset'))) {
      return "To reset your password:\n\n1. On the login page, click 'Forgot Password?'\n2. Enter your email address\n3. Check your email for reset instructions\n4. Click the link in the email\n5. Enter your new password\n\nThe reset link expires in 1 hour for security.";
    }

    if (message.includes('login') || message.includes('sign in')) {
      return "Having trouble logging in?\n\n• Make sure you're using the correct email and password\n• Check if Caps Lock is on\n• Try resetting your password if you've forgotten it\n• Ensure the backend server is running\n\nIf problems persist, the server might be down.";
    }

    if (message.includes('logout') || message.includes('sign out')) {
      return "To sign out:\n\n1. Click the 'Sign Out' button in the top-right corner of the dashboard\n2. You'll be redirected to the login page\n\nYour session will be cleared and you'll need to log in again to access your events.";
    }

    if (message.includes('account') || message.includes('profile')) {
      return "Your account information:\n\n• Your email is displayed in the dashboard header\n• Currently, you can't change your email through the UI\n• You can reset your password using the 'Forgot Password' feature\n• All your events are tied to your account";
    }

    if (message.includes('time') || message.includes('date')) {
      return "About event dates and times:\n\n• Use the date/time picker when creating events\n• Times are displayed in your local timezone\n• You can schedule events for any future date\n• Past dates are allowed if you're logging historical events\n• The format shown is: MM/DD/YYYY HH:MM AM/PM";
    }

    if (message.includes('description')) {
      return "Event descriptions:\n\n• Descriptions are optional but recommended\n• You can include details like location, agenda, or notes\n• There's no character limit\n• Descriptions appear on the event cards\n• You can leave it blank for simple events";
    }

    if (message.includes('dashboard') || message.includes('home')) {
      return "Your dashboard features:\n\n• View all your events in a card layout\n• Events are sorted by date (earliest first)\n• Each card shows title, date/time, and description\n• Use the edit and delete buttons on each card\n• Click '+ Add Event' to create new events\n• Your email is shown in the header";
    }

    if (message.includes('mobile') || message.includes('phone')) {
      return "Mobile experience:\n\n• The website is fully responsive\n• Works on phones, tablets, and desktops\n• Touch-friendly buttons and forms\n• Optimized layouts for smaller screens\n• All features available on mobile";
    }

    if (message.includes('data') || message.includes('save')) {
      return "Your data:\n\n• All events are saved to a secure database\n• Data persists between sessions\n• Only you can see your events (private to your account)\n• Events are automatically saved when created/edited\n• No manual save required";
    }

    if (message.includes('help') || message.includes('support')) {
      return "I'm here to help! I can assist with:\n\n• Event management (create, edit, delete)\n• Login and password issues\n• Navigation and features\n• Technical questions\n• Account management\n\nJust ask me anything about using the Event Management System!";
    }

    if (message.includes('security') || message.includes('safe')) {
      return "Security features:\n\n• Passwords are encrypted and secure\n• JWT tokens for session management\n• Your data is private to your account\n• Password reset tokens expire for safety\n• HTTPS encryption (in production)\n• No data is shared with third parties";
    }

    if (message.includes('feature') || message.includes('what can')) {
      return "Event Management System features:\n\n Create unlimited events\n Edit event details anytime\n Delete unwanted events\n Secure user authentication\n Password reset functionality\n Responsive design\n Real-time updates\n Private event storage\n\nEverything you need to manage your events efficiently!";
    }

    // Greetings
    if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
      return "Hello!  I'm here to help you with the Event Management System. What would you like to know about creating, editing, or managing your events?";
    }

    if (message.includes('thank')) {
      return "You're welcome! 😊 Feel free to ask if you need any more help with managing your events.";
    }

    if (message.includes('bye') || message.includes('goodbye')) {
      return "Goodbye!  I'll be here whenever you need help with your events. Have a great day!";
    }

   
    return "I'd be happy to help! I can assist you with:\n\n• Creating and managing events\n• Login and password issues\n• Account questions\n• Feature explanations\n• Navigation help\n\nCould you please be more specific about what you'd like to know? For example, you could ask:\n• 'How do I create an event?'\n• 'How do I reset my password?'\n• 'How do I edit an event?'";
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

   
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getResponse(inputText),
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); 
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickQuestions = [
    "How do I create an event?",
    "How do I reset my password?",
    "How do I edit an event?",
    "What features are available?"
  ];

  return (
    <>
  
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-all duration-300 hover:scale-110 z-50"
          aria-label="Open chat"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}

     
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-white rounded-lg shadow-2xl border border-gray-200 flex flex-col z-50">
          
          <div className="bg-blue-600 text-white p-4 rounded-t-lg flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5" />
              <span className="font-semibold">Event Assistant</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-gray-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.isBot
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {message.isBot && <Bot className="w-4 h-4 mt-0.5 flex-shrink-0" />}
                    <div className="whitespace-pre-line text-sm">{message.text}</div>
                    {!message.isBot && <User className="w-4 h-4 mt-0.5 flex-shrink-0" />}
                  </div>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 text-gray-800 p-3 rounded-lg max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <Bot className="w-4 h-4" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            
            {messages.length === 1 && (
              <div className="space-y-2">
                <p className="text-sm text-gray-600 font-medium">Quick questions:</p>
                {quickQuestions.map((question, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setInputText(question);
                      setTimeout(handleSendMessage, 100);
                    }}
                    className="block w-full text-left p-2 text-sm bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors border border-blue-200"
                  >
                    <HelpCircle className="w-3 h-3 inline mr-2" />
                    {question}
                  </button>
                ))}
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          
          <div className="p-4 border-t border-gray-200">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isTyping}
                className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;